package fr.epsi.atlas.monnaie.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import fr.epsi.atlas.monnaie.modele.Monnaie;

@Repository
public class MonnaieDao {

	@PersistenceContext
	private EntityManager em;

	/**
	 * Ajoute la monnaie dans la base de données. Si
	 * la monnaie existe déjà, cette méthode met à jour
	 * les informations de la monnaie (si nécessaire)
	 *
	 * @param monnaie
	 */
	public void createOrUpdate(Monnaie monnaie) {
		em.merge(monnaie);
	}

	/**
	 * @param code
	 * @return Retourne la monnaie correspondant au code ou null si elle n'existe pas.
	 */
	public Monnaie getByCode(String code) {
		return em.find(Monnaie.class, code);
	}

	/**
	 * Supprime de la base de données une monnaie à partir de son code.
	 * Cette méthode est sans effet si la monnaie n'existe pas.
	 * @param code
	 */
	public void deleteByCode(String code) {
		em.createQuery("delete from Monnaie m where m.code = :code")
		  .setParameter("code", code)
		  .executeUpdate();
	}
}
