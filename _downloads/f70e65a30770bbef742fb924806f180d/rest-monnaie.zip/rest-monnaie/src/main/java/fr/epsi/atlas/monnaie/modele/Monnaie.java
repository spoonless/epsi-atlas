package fr.epsi.atlas.monnaie.modele;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Monnaie {

	/**
	 * le code ISO-4217
	 */
	@Id
	private String code;
	private BigDecimal tauxDeChange;

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public BigDecimal getTauxDeChange() {
		return tauxDeChange;
	}
	public void setTauxDeChange(BigDecimal tauxDeChange) {
		this.tauxDeChange = tauxDeChange;
	}
}
